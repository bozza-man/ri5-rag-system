#!/usr/bin/env bash
set -euo pipefail

# Enhanced Pi5 RAG Installer Script
# Version: 2.0
# Author: Enhanced by AI Assistant

BOLD="\033[1m"
GREEN="\033[32m"
RED="\033[31m"
YELLOW="\033[33m"
BLUE="\033[34m"
RESET="\033[0m"

log() { echo -e "${BOLD}[pi5-installer]${RESET} $1" >&2; }
log_success() { echo -e "${GREEN}✓${RESET} $1" >&2; }
log_error() { echo -e "${RED}✗${RESET} $1" >&2; }
log_warning() { echo -e "${YELLOW}⚠${RESET} $1" >&2; }
log_info() { echo -e "${BLUE}ℹ${RESET} $1" >&2; }

# Configuration
SCRIPT_VERSION="2.0"
MIN_DISK_SPACE_GB=2
MIN_MEMORY_GB=2
DEFAULT_PROJECT_DIR="$PWD/pi5_rag_test"

# System validation functions
check_system_requirements() {
  log "Checking system requirements..."
  
  # Check available disk space
  local available_space_gb
  available_space_gb=$(df / | awk 'NR==2 {print int($4/1024/1024)}')
  if [ "$available_space_gb" -lt "$MIN_DISK_SPACE_GB" ]; then
    log_error "Insufficient disk space. Required: ${MIN_DISK_SPACE_GB}GB, Available: ${available_space_gb}GB"
    exit 1
  fi
  log_success "Disk space check passed (${available_space_gb}GB available)"
  
  # Check memory (portable across Linux/macOS)
  local total_memory_gb
  if command -v free >/dev/null 2>&1; then
    # Linux
    total_memory_gb=$(free -g | awk 'NR==2{print int($2)}')
  elif [ -f /proc/meminfo ]; then
    # Linux fallback
    total_memory_gb=$(awk '/MemTotal/ {print int($2/1024/1024)}' /proc/meminfo)
  elif command -v sysctl >/dev/null 2>&1; then
    # macOS
    total_memory_gb=$(sysctl -n hw.memsize | awk '{print int($1/1024/1024/1024)}')
  else
    log_warning "Cannot determine memory size, skipping memory check"
    return 0
  fi
  
  if [ "$total_memory_gb" -lt "$MIN_MEMORY_GB" ]; then
    log_warning "Low memory detected (${total_memory_gb}GB). RAG system may perform slowly."
  else
    log_success "Memory check passed (${total_memory_gb}GB available)"
  fi
  
  # Check if running on Pi5 (optional)
  if [ -f /proc/cpuinfo ] && grep -q "BCM2712" /proc/cpuinfo; then
    log_success "Raspberry Pi 5 detected"
  else
    log_warning "Not running on Pi5 - performance may vary"
  fi
}

show_help() {
  cat << EOF
Pi5 RAG Installer v${SCRIPT_VERSION}

Usage: $0 [OPTIONS]

Options:
  -h, --help              Show this help message
  -d, --dir DIR           Installation directory (default: ${DEFAULT_PROJECT_DIR})
  -s, --skip-validation   Skip system requirements check
  -f, --force             Force installation even if project directory exists
  --no-docker             Skip Docker installation (assume already installed)
  --no-ingest             Skip sample data ingestion
  --dry-run               Show what would be installed without actually installing

Environment Variables:
  OPENAI_API_KEY          OpenAI API key for embeddings (optional)
  RCLONE_REMOTE           Rclone remote for backup sync (optional)
  BATCH_MODE=1            Non-interactive mode

Examples:
  $0                                    # Install with defaults
  $0 -d /opt/rag                        # Install to custom directory
  $0 --dry-run                          # Preview installation
  OPENAI_API_KEY=sk-... $0              # Install with API key

EOF
}

require_root() {
  if [ "$(id -u)" -ne 0 ]; then
    log "Elevating privileges with sudo..."
    exec sudo --preserve-env=OPENAI_API_KEY,BATCH_MODE,RCLONE_REMOTE -E "$0" "$@"
  fi
}

detect_os() {
  if [ -f /etc/os-release ]; then 
    . /etc/os-release
  else
    log_error "Cannot determine OS. Aborting."
    exit 1
  fi
  
  export DISTRO_ID="${ID:-debian}"
  export DISTRO_CODENAME="${VERSION_CODENAME:-bookworm}"
  export ARCH="$(dpkg --print-architecture 2>/dev/null || echo arm64)"
  
  if [ "$ARCH" != "arm64" ] && [ "$ARCH" != "aarch64" ]; then
    log_warning "Non-ARM64 architecture ($ARCH) detected; continuing anyway."
  fi
  
  log_success "Detected $DISTRO_ID $DISTRO_CODENAME on $ARCH"
}

apt_install() {
  log "Refreshing apt metadata..."
  if ! apt-get update -y; then
    log_error "Failed to update package lists"
    exit 1
  fi
  
  log "Installing packages: $*"
  if ! DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "$@"; then
    log_error "Failed to install packages: $*"
    exit 1
  fi
  log_success "Successfully installed packages"
}

install_docker() {
  if command -v docker >/dev/null 2>&1; then
    log_success "Docker already installed"
    return 0
  fi
  
  log "Installing Docker Engine and compose plugin from Docker's apt repo..."
  
  # Install prerequisites
  apt_install ca-certificates curl gnupg lsb-release
  
  # Create keyring directory
  install -m 0755 -d /etc/apt/keyrings
  
  # Add Docker's GPG key
  if [ ! -f /etc/apt/keyrings/docker.gpg ]; then
    log "Adding Docker's GPG key..."
    if ! curl -fsSL "https://download.docker.com/linux/${DISTRO_ID:-debian}/gpg" | gpg --dearmor -o /etc/apt/keyrings/docker.gpg; then
      log_error "Failed to add Docker's GPG key"
      exit 1
    fi
    chmod a+r /etc/apt/keyrings/docker.gpg
  fi
  
  # Add Docker repository
  log "Adding Docker repository..."
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/${DISTRO_ID:-debian} $DISTRO_CODENAME stable" > /etc/apt/sources.list.d/docker.list
  
  # Update package lists and install Docker
  if ! apt-get update -y; then
    log_error "Failed to update package lists after adding Docker repo"
    exit 1
  fi
  
  if ! DEBIAN_FRONTEND=noninteractive apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin; then
    log_error "Failed to install Docker packages"
    exit 1
  fi
  
  # Enable and start Docker service
  if ! systemctl enable --now docker; then
    log_warning "Failed to enable/start Docker service, but installation completed"
  fi
  
  # Verify Docker installation
  if docker --version >/dev/null 2>&1; then
    log_success "Docker installed successfully: $(docker --version)"
  else
    log_error "Docker installation verification failed"
    exit 1
  fi
}

post_docker_user() {
  local user_name="${SUDO_USER:-$USER}"
  if [ -z "$user_name" ]; then
    log_warning "Could not determine user name for docker group"
    return 0
  fi
  
  if id -nG "$user_name" | tr ' ' '\n' | grep -q '^docker$'; then
    log_success "User $user_name already in docker group"
  else
    log "Adding $user_name to docker group..."
    if usermod -aG docker "$user_name"; then
      log_success "User $user_name added to docker group"
      log_info "You must log out and back in for group changes to take effect"
    else
      log_warning "Failed to add $user_name to docker group"
    fi
  fi
}

install_basics() {
  apt_install python3 python3-venv python3-pip rclone unzip curl
}

extract_project() {
  local target_dir="${1:-$DEFAULT_PROJECT_DIR}"
  
  # Check if directory already exists
  if [ -d "$target_dir" ] && [ "${FORCE_INSTALL:-0}" != "1" ]; then
    log_error "Directory $target_dir already exists. Use --force to overwrite."
    exit 1
  fi
  
  # Create target directory
  if ! mkdir -p "$target_dir"; then
    log_error "Failed to create directory: $target_dir"
    exit 1
  fi
  
  # Find the archive file
  local archive_file=""
  local script_dir="$(dirname "$0")"
  
  # Look for archive in the same directory as the script
  if [ -f "$script_dir/pi5_rag_test_archive.zip" ]; then
    archive_file="$script_dir/pi5_rag_test_archive.zip"
  elif [ -f "./pi5_rag_test_archive.zip" ]; then
    archive_file="./pi5_rag_test_archive.zip"
  elif [ -f "pi5_rag_test_archive.zip" ]; then
    archive_file="pi5_rag_test_archive.zip"
  else
    log_error "Archive file 'pi5_rag_test_archive.zip' not found"
    log_info "Please ensure the archive file is in the same directory as this script"
    exit 1
  fi
  
  log "Unpacking project archive from $archive_file into $target_dir"
  
  # Copy and extract the project archive
  if ! cp "$archive_file" "$target_dir/pi5_rag_test.zip"; then
    log_error "Failed to copy project archive"
    exit 1
  fi
  
  # Unzip the project
  if ! (cd "$target_dir" && unzip -o pi5_rag_test.zip >/dev/null && rm -f pi5_rag_test.zip); then
    log_error "Failed to unzip project files"
    exit 1
  fi
  
  log_success "Project extracted to $target_dir"
  echo "$target_dir"
}

prepare_env() {
  local dir="$1"
  cd "$dir"
  
  if [ ! -f .env ]; then
    log "Creating .env file from template..."
    if ! cp .env.example .env; then
      log_error "Failed to create .env file"
      exit 1
    fi
    
    # Generate secure Qdrant API key
    if grep -q '^QDRANT_API_KEY=change-me' .env; then
      local key
      key="$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 48)"
      if ! sed -i "s|^QDRANT_API_KEY=change-me|QDRANT_API_KEY=$key|" .env; then
        log_warning "Failed to set Qdrant API key"
      else
        log_success "Generated secure Qdrant API key"
      fi
    fi
    
    # Set OpenAI API key if provided
    if [ -n "${OPENAI_API_KEY:-}" ] && [ "$OPENAI_API_KEY" != "sk-..." ]; then
      if sed -i "s|^OPENAI_API_KEY=sk-...|OPENAI_API_KEY=$OPENAI_API_KEY|" .env; then
        log_success "Set OpenAI API key from environment"
      fi
    fi
    
    # Set Rclone remote if provided
    if [ -n "${RCLONE_REMOTE:-}" ]; then
      if sed -i "s|^RCLONE_REMOTE=|RCLONE_REMOTE=$RCLONE_REMOTE|" .env; then
        log_success "Set Rclone remote from environment"
      fi
    fi
    
    log_success "Environment configuration completed"
  else
    log_success "Environment file already exists"
  fi
}

compose_up() {
  local dir="$1"
  cd "$dir"
  
  log "Starting Qdrant with docker compose..."
  if ! docker compose --env-file .env up -d; then
    log_error "Failed to start Qdrant container"
    exit 1
  fi
  
  log "Waiting for Qdrant health endpoint..."
  local max_attempts=30
  local attempt=1
  
  while [ $attempt -le $max_attempts ]; do
    if curl -fsS http://localhost:6333/healthz >/dev/null 2>&1; then
      log_success "Qdrant is healthy and ready"
      return 0
    fi
    
    if [ $attempt -eq $max_attempts ]; then
      log_error "Qdrant failed to become healthy after $max_attempts attempts"
      log_info "Container logs:"
      docker compose logs qdrant
      exit 1
    fi
    
    log_info "Waiting for Qdrant... (attempt $attempt/$max_attempts)"
    sleep 2
    attempt=$((attempt + 1))
  done
}

setup_python() {
  local dir="$1"
  cd "$dir"
  
  if [ ! -d .venv ]; then
    log "Creating Python virtual environment..."
    if ! python3 -m venv .venv; then
      log_error "Failed to create Python virtual environment"
      exit 1
    fi
    log_success "Python virtual environment created"
  else
    log_success "Python virtual environment already exists"
  fi
  
  log "Activating virtual environment and installing dependencies..."
  if ! . .venv/bin/activate; then
    log_error "Failed to activate virtual environment"
    exit 1
  fi
  
  log "Upgrading pip..."
  if ! pip install --upgrade pip >/dev/null 2>&1; then
    log_warning "Failed to upgrade pip, continuing anyway"
  fi
  
  log "Installing Python dependencies..."
  if ! pip install -r requirements.txt >/dev/null 2>&1; then
    log_error "Failed to install Python dependencies"
    log_info "Trying with verbose output..."
    pip install -r requirements.txt
    exit 1
  fi
  
  log_success "Python dependencies installed successfully"
}

maybe_ingest() {
  local dir="$1"
  cd "$dir"
  
  # Skip if explicitly requested
  if [ "${SKIP_INGEST:-0}" = "1" ]; then
    log_info "Skipping sample data ingestion (--no-ingest flag)"
    return 0
  fi
  
  set +u
  source .env || true
  set -u
  
  local key="${OPENAI_API_KEY:-}"
  if [ -n "$key" ] && [ "$key" != "sk-..." ]; then
    log "OPENAI_API_KEY detected; performing sample ingest..."
    
    if ! . .venv/bin/activate; then
      log_error "Failed to activate virtual environment for ingestion"
      return 1
    fi
    
    log "Ingesting sample documents..."
    if python -m src.ingest; then
      log_success "Sample data ingestion completed"
      
      log "Running example query..."
      if python -m src.query "escalation after-hours"; then
        log_success "Example query completed successfully"
      else
        log_warning "Example query failed, but ingestion was successful"
      fi
    else
      log_warning "Sample data ingestion failed, but system is still functional"
    fi
  else
    log_info "No usable OPENAI_API_KEY found; skipping ingest"
    log_info "You can run ingestion later with: source .venv/bin/activate && python -m src.ingest"
  fi
}

install_sync_timer() {
  local dir="$1"
  cd "$dir"
  
  set +u
  source .env || true
  set -u
  
  local remote="${RCLONE_REMOTE:-}"
  if [ -z "$remote" ]; then
    log_info "RCLONE_REMOTE not set in .env; leaving snapshot sync timer disabled"
    return 0
  fi
  
  local name="${remote%%:*}"
  if rclone listremotes 2>/dev/null | grep -q "^$name:"; then
    log "Installing systemd unit and timer for snapshot sync to $remote"
    
    if [ ! -f "systemd/qdrant-snapshot-sync.service" ] || [ ! -f "systemd/qdrant-snapshot-sync.timer" ]; then
      log_warning "Systemd service files not found, skipping timer installation"
      return 0
    fi
    
    if ! cp systemd/qdrant-snapshot-sync.* /etc/systemd/system/; then
      log_error "Failed to copy systemd service files"
      return 1
    fi
    
    if ! systemctl daemon-reload; then
      log_error "Failed to reload systemd daemon"
      return 1
    fi
    
    if ! systemctl enable --now qdrant-snapshot-sync.timer; then
      log_warning "Failed to enable snapshot sync timer"
    else
      log_success "Snapshot sync timer installed and enabled"
    fi
  else
    log_warning "rclone remote '$name' not configured; run 'rclone config' and re-run installer to enable timer"
  fi
}

# Parse command line arguments
parse_args() {
  while [[ $# -gt 0 ]]; do
    case $1 in
      -h|--help)
        show_help
        exit 0
        ;;
      -d|--dir)
        DEFAULT_PROJECT_DIR="$2"
        shift 2
        ;;
      -s|--skip-validation)
        SKIP_VALIDATION=1
        shift
        ;;
      -f|--force)
        FORCE_INSTALL=1
        shift
        ;;
      --no-docker)
        SKIP_DOCKER=1
        shift
        ;;
      --no-ingest)
        SKIP_INGEST=1
        shift
        ;;
      --dry-run)
        DRY_RUN=1
        shift
        ;;
      *)
        log_error "Unknown option: $1"
        show_help
        exit 1
        ;;
    esac
  done
}

# Dry run mode - show what would be installed
show_dry_run() {
  log "DRY RUN MODE - No changes will be made"
  log "======================================"
  
  log "System checks:"
  log "  - OS detection: $(grep PRETTY_NAME /etc/os-release 2>/dev/null | cut -d'"' -f2 || echo "Unknown")"
  log "  - Architecture: $(dpkg --print-architecture 2>/dev/null || echo "Unknown")"
  log "  - Available disk space: $(df / | awk 'NR==2 {print int($4/1024/1024)}')GB"
  log "  - Total memory: $(if command -v free >/dev/null 2>&1; then free -g | awk 'NR==2{print int($2)}'; elif [ -f /proc/meminfo ]; then awk '/MemTotal/ {print int($2/1024/1024)}' /proc/meminfo; elif command -v sysctl >/dev/null 2>&1; then sysctl -n hw.memsize | awk '{print int($1/1024/1024/1024)}'; else echo "Unknown"; fi)GB"
  
  log ""
  log "Installation plan:"
  log "  - Project directory: $DEFAULT_PROJECT_DIR"
  log "  - Docker installation: $([ "${SKIP_DOCKER:-0}" = "1" ] && echo "SKIPPED" || echo "YES")"
  log "  - Python virtual environment: YES"
  log "  - Qdrant vector database: YES"
  log "  - Sample data ingestion: $([ "${SKIP_INGEST:-0}" = "1" ] && echo "SKIPPED" || echo "YES (if OpenAI API key provided)")"
  log "  - Backup sync timer: YES (if Rclone configured)"
  
  log ""
  log "Environment variables:"
  log "  - OPENAI_API_KEY: $([ -n "${OPENAI_API_KEY:-}" ] && echo "SET" || echo "NOT SET")"
  log "  - RCLONE_REMOTE: $([ -n "${RCLONE_REMOTE:-}" ] && echo "SET" || echo "NOT SET")"
  
  exit 0
}

# Installation summary
show_summary() {
  local dir="$1"
  
  log ""
  log "=========================================="
  log_success "Pi5 RAG Installation Complete!"
  log "=========================================="
  log ""
  log "Project directory: $dir"
  log ""
  log "Next steps:"
  log "1. If you were added to the docker group, log out and back in"
  log "2. Navigate to the project directory: cd $dir"
  log "3. Activate the virtual environment: source .venv/bin/activate"
  log ""
  
  if [ -z "${OPENAI_API_KEY:-}" ] || [ "$OPENAI_API_KEY" = "sk-..." ]; then
    log "To enable full functionality:"
    log "  - Set your OpenAI API key in .env file"
    log "  - Run: python -m src.ingest"
  fi
  
  log ""
  log "Useful commands:"
  log "  - Query the system: python -m src.query \"your question\""
  log "  - Check Qdrant status: docker compose ps"
  log "  - View logs: docker compose logs qdrant"
  log "  - Stop services: docker compose down"
  log ""
}

# Post-installation validation
validate_installation() {
  local dir="$1"
  cd "$dir"
  
  log "Validating installation..."
  
  # Check if Docker is running
  if ! docker info >/dev/null 2>&1; then
    log_warning "Docker is not running or not accessible"
    return 1
  fi
  
  # Check if Qdrant container is running
  if ! docker compose ps | grep -q "qdrant.*Up"; then
    log_warning "Qdrant container is not running"
    return 1
  fi
  
  # Check if Qdrant is responding
  if ! curl -fsS http://localhost:6333/healthz >/dev/null 2>&1; then
    log_warning "Qdrant health check failed"
    return 1
  fi
  
  # Check if Python virtual environment exists
  if [ ! -d ".venv" ]; then
    log_warning "Python virtual environment not found"
    return 1
  fi
  
  # Check if required Python packages are installed
  if ! . .venv/bin/activate && python -c "import openai, qdrant_client" >/dev/null 2>&1; then
    log_warning "Required Python packages not properly installed"
    return 1
  fi
  
  log_success "Installation validation passed"
  return 0
}

main() {
  # Parse command line arguments
  parse_args "$@"
  
  # Show dry run if requested
  if [ "${DRY_RUN:-0}" = "1" ]; then
    show_dry_run
  fi
  
  # Show banner
  log "Pi5 RAG Installer v${SCRIPT_VERSION}"
  log "=================================="
  
  # Check system requirements unless skipped
  if [ "${SKIP_VALIDATION:-0}" != "1" ]; then
    check_system_requirements
  fi
  
  # Require root privileges
  require_root "$@"
  
  # Detect OS
  detect_os
  
  # Install Docker unless skipped
  if [ "${SKIP_DOCKER:-0}" != "1" ]; then
    install_docker
    post_docker_user
  else
    log_info "Skipping Docker installation (--no-docker flag)"
  fi
  
  # Install basic packages
  install_basics
  
  # Extract and setup project
  local dir
  dir="$(extract_project "$DEFAULT_PROJECT_DIR")"
  prepare_env "$dir"
  compose_up "$dir"
  setup_python "$dir"
  maybe_ingest "$dir"
  install_sync_timer "$dir"
  
  # Validate installation
  if ! validate_installation "$dir"; then
    log_warning "Installation validation failed, but continuing..."
  fi
  
  # Show completion summary
  show_summary "$dir"
}

main "$@"

exit 0
__ARCHIVE_B64__
